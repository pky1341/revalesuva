<!DOCTYPE html>
<html>

<head>
    <title>Your Account Credentials</title>
</head>

<body>
    <h1>Welcome!</h1>
    <p>Your account has been created successfully.</p>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Password:</strong> <?php echo e($password); ?></strong></p>
</body>

</html><?php /**PATH /var/www/html/resources/views/emails/user_credentials.blade.php ENDPATH**/ ?>