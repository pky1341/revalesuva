<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\ApiResponser;
use Illuminate\Support\Facades\Validator;
use App\Models\CMS;

class CMSController extends Controller
{
    use ApiResponser;
    public function getCMS(){
        $cms = CMS::all();
        if (!$cms) {
            return $this->errorResponse('No CMS found.', 404);
        }
        return $this->successResponse($cms,'CMS is available',200);
    }
}
