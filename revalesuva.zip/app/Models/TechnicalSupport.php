<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TechnicalSupport extends Model
{    
    /**
     * guarded
     *
     * @var array
     */
    protected $table = "technical_support";
    protected $guarded = ['id', 'created_at', 'updated_at'];
     public $timestamps = true;

    public function user(){
        return $this->belongsTo(User::class);
    }
}
