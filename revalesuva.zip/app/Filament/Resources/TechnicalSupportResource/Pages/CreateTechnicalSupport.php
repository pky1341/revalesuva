<?php

namespace App\Filament\Resources\TechnicalSupportResource\Pages;

use App\Filament\Resources\TechnicalSupportResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTechnicalSupport extends CreateRecord
{
    protected static string $resource = TechnicalSupportResource::class;
}
