<?php

namespace App\Filament\Resources\CMSResource\Pages;

use App\Filament\Resources\CMSResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCMS extends CreateRecord
{
    protected static string $resource = CMSResource::class;
}
