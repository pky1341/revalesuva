<?php

namespace App\Filament\Resources\InquiryServiceResource\Pages;

use App\Filament\Resources\InquiryServiceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInquiryService extends CreateRecord
{
    protected static string $resource = InquiryServiceResource::class;
}
